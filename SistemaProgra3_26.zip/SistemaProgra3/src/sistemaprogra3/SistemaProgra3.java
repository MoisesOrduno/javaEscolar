
package sistemaprogra3;

public class SistemaProgra3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        frmPrincipal forma = new frmPrincipal();
        forma.setVisible(true);
    }
    
}
