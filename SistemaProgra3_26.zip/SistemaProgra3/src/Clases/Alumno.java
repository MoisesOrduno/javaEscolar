package Clases;

public class Alumno {
    private String ID;
    private String Nombre;
    private String Correo;
    private int Edad;

    public Alumno(String ID, String Nombre, String Correo, int Edad) {
        this.ID = ID;
        this.Nombre = Nombre;
        this.Correo = Correo;
        this.Edad = Edad;
    }

    public Alumno() {
    }
    
    public Object[] toObject(){
        Object[] obj = new Object[]{this.ID,
                            this.Nombre, 
                            this.Correo,this.Edad};
        return obj;
    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getCorreo() {
        return Correo;
    }

    public void setCorreo(String Correo) {
        this.Correo = Correo;
    }

    public int getEdad() {
        return Edad;
    }

    public void setEdad(int Edad) {
        this.Edad = Edad;
    }
    
}
