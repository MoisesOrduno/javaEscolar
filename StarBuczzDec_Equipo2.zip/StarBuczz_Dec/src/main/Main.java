/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import clases.soya;
import clases.bebida;
import clases.condimento_abs;
import clases.darkRoast;
import clases.decaf;
import clases.expreso;
import clases.mocha;

/**
 *
 * @author danij
 */
public class Main {
    public static void main(String[] args) {
        bebida bebida = new decaf();
        bebida bebida2 = new expreso();
        bebida bebida3 = new darkRoast();
        
        bebida2 = new mocha(bebida);
        bebida = new soya(bebida);
        
        
        
        
       
        
        
        
        System.out.println(bebida.getDescripcion()+" Su precio es: "+bebida.getPrecio());
        System.out.println(bebida2.getDescripcion()+" Su precio es: "+bebida2.getPrecio());
        System.out.println(bebida3.getDescripcion()+" Su precio es: "+bebida3.getPrecio());
        
        
        
    }
    
}
