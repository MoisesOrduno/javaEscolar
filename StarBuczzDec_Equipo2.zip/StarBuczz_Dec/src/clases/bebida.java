/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

/**
 *
 * @author juan carlos
 */
public abstract class bebida {
    
    public abstract double getPrecio();
    public abstract String getDescripcion();
    
    
   
    
}

