package clases;


import clases.bebida;
import clases.condimento_abs;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author danij
 */
public class soya extends condimento_abs{
    
    public soya( bebida Bebida){
    this.Bebida = Bebida;
    
    }
    
    @Override
    public double getPrecio() {
 return Bebida.getPrecio()+9.00;
    }

    @Override
    public String getDescripcion() {
    return Bebida.getDescripcion()+ " con leche de soya";   
    }
}
